package org.example;

import lombok.Setter;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Teacher[] teachers = {new Teacher("Yi", 40), new Teacher("Wang", 40)};
        Teacher[] teachers2 = {new Teacher("Yi", 40), new Teacher("Wang", 40)};

        increaseAge(teachers, 5);

        System.out.println(Arrays.toString(teachers));
        System.out.println(Arrays.equals(teachers2, teachers));

    }

    /**
     * adds elements of an array
     * @param nums the input array
     * @return the sum of all elements of the input array
     */
    public static double sum(double[] nums) {
        // use enhanced for loop    2mins 2:03
        double sum = 0;

        for (double num : nums) {
            sum += num;
        }

        return sum;
    }

    /**
     * increases every element of the array by a certain value
     * e.g.: {1,2,3}, 1 -> {2,3,4}
     * @param nums the original array
     * @param value the value to increase
     */
    public static void increase(double[] nums, double value) {
        for (int i = 0; i < nums.length; i++) {
            nums[i] += value;
        }
    }

    /**
     * increases the age of all teachers of a teacher array by value
     * @param teachers the teacher array
     * @param value the amount of age to increase
     */
    public static void increaseAge(Teacher[] teachers, int value) {
        for (Teacher teacher : teachers) {
            teacher.increaseAge(value);
        }
    }

    /**
     * counts the number vowels in a string
     * @param str the input string
     * @return the number of vowels in the string
     */
    public static int countVowels(String str) {
        int count = 0;
        for (char c : str.toLowerCase().toCharArray()) {
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                count++;
            }
        }

        return count;
    }

}