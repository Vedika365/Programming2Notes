package org.example;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class Teacher {
    private String id;
    private String name;
    private int age;

    private static int nextId = 1;

    public Teacher(String name, int age) {
        this.id = String.format("%05d", nextId++);
        this.age = age;
        this.name = name;
    }

    /**
     * increases the age by a certain amount
     * @param value the amount to increase
     */
    public void increaseAge(int value) {
        age += value;
    }
}
