package org.example;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@EqualsAndHashCode
@ToString
@Getter
@Setter
public class Student {
    private String id;
    private String name;
    private String gender;
    private Course course1;
    private Course course2;

    private static int nextId = 1;

    public Student(String name, String gender) {
        this(name, gender, null, null);
    }

    public Student(String name, String gender, Course course1, Course course2) {
        this.id = String.format("%05d", nextId++);
        this.name = name;
        this.gender = gender;
        this.course1 = course1;
        this.course2 = course2;
    }

    // constructor with only name and gender
    // constructor with name, gender, and two courses
    // equals
    // toString
    // getter
    // setter
}
