package org.example;

import java.security.InvalidParameterException;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Cat> cats = new ArrayList<>();

        Cat c1 = new Cat("lucy", "female", 3);
        Cat c2 = new Cat("lucky", "male", 2);
        Cat c3 = new Cat("snow", "female", 1);

        cats.add(c1);
        cats.add(c2);
        cats.add(c3);

        // stream.filter
        long count = cats.stream().filter(cat -> cat.getGender().equals("female"))
                        .count();

        // stream.forEach
        cats.stream().forEach(cat -> cat.increaseAge());// lambda expression
        cats.stream().forEach(Cat::increaseAge);        // method reference

        cats.stream().forEach(cat -> System.out.println(cat));      // lambda expression
        cats.stream().forEach(System.out::println);                 // method reference

        List<Integer> nums = new ArrayList<>();
        nums.add(65);
        nums.add(92);
        nums.add(47);
        nums.add(80);
        nums.add(58);

        // stream.map
        // bring all scores between [55, 60) to 60
        List<Integer> nums2 = nums.stream()
                .map(num -> (num >= 55 && num < 60) ? 60 : num)
                .toList();
        System.out.println(nums2);
    }

    /**
     * returns a list of valid string, a valid string must contain at least one vowel
     * the string in the result list must be lowercase.
     * e.g.: {"HI", "apple", "MM", "213", "Java"} -> {"hi", "apple", "java"}
     * @param strs the input string list
     * @return the result string list that only contains lowercase strings that contain vowels
     */
    public static List<String> process(List<String> strs) {
        return strs.stream()
                .filter(Main::containsVowel)
                .map(String::toLowerCase)
                .toList();
    }

    private static boolean containsVowel(String str) {
        for (char c : str.toLowerCase().toCharArray()) {
            if ("aeiou".contains(c + "")) {
                return true;
            }
        }
        return false;
    }

    public static long fibonacci(int num) {
        if (num < 0) {
            throw new InvalidParameterException();
        }
        if (num == 1) {
            return 1L;
        }
        long result = 0;

        long f0 = 0;
        long f1 = 1;

        for (int i = 2; i <= num; i++) {
            result = f0 + f1;
            f0 = f1;
            f1 = result;
        }

        return result;
    }
}