package org.example;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TaskManager {
    private ArrayList<Task> tasks;

    public TaskManager() {
        this.tasks = new ArrayList<>();
    }

    public TaskManager(ArrayList<Task> tasks) {
        this.tasks = tasks;
    }

    public void export() {
        File file = new File("src/main/resources/allTasks.csv");

        try (FileWriter fw = new FileWriter(file)) {
            for (Task task : tasks) {
                fw.write(task.id + ",");
                fw.write(task.name + ",");
                fw.write(task.expectedAmountOfDay + ",");
                if (task instanceof CodingTask codingTask) {
                    fw.write(codingTask.getLength() + ",");
                    fw.write(codingTask.getLanguage() + "\n");
                } else if (task instanceof DocumentationTask documentationTask) {
                    fw.write(documentationTask.getPage() + ",");
                    fw.write(documentationTask.getDocumentType() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void export(String type) {
        switch (type.toLowerCase()) {
            case "c" -> exportCodeTask();
            case "d" -> exportDocumentationTask();
            default -> export();
        }
    }

    private void exportCodeTask() {
        File file = new File("src/main/resources/CodingTasks.csv");

        try (FileWriter fw = new FileWriter(file)) {
            for (Task task : tasks) {
                if (task instanceof CodingTask codingTask) {
                    fw.write(task.id + ",");
                    fw.write(task.name + ",");
                    fw.write(task.expectedAmountOfDay + ",");
                    fw.write(codingTask.getLength() + ",");
                    fw.write(codingTask.getLanguage() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void exportDocumentationTask() {
        File file = new File("src/main/resources/DocumentationTasks.csv");

        try (FileWriter fw = new FileWriter(file)) {
            for (Task task : tasks) {
                if (task instanceof DocumentationTask documentationTask) {
                    fw.write(task.id + ",");
                    fw.write(task.name + ",");
                    fw.write(task.expectedAmountOfDay + ",");
                    fw.write(documentationTask.getPage() + ",");
                    fw.write(documentationTask.getDocumentType() + "\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
