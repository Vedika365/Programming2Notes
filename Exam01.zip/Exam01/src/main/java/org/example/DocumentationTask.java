package org.example;

import java.util.Objects;

public class DocumentationTask extends Task implements Printable {
    private int page;
    private String documentType;

    public DocumentationTask() {
        super();
        this.page = 0;
        this.documentType = "";
    }

    public DocumentationTask(int id, String name, int expectedAmountOfDay, int length, String language) {
        super(id, name, expectedAmountOfDay);
        this.page = length;
        this.documentType = language;
    }

    /**
     * prints Coding task version of processing message
     */
    @Override
    public void process() {
        System.out.println("Processing...");
        System.out.printf("%d pages of %s document", page, documentType);
    }

    @Override
    public double calcPrice(boolean isColor) {
        int colorPageThreshould = 20;
        int bwPageThreshould = 20;
        double colorLowPrice = 0.15;
        double colorHighPrice = 0.3;
        double bwLowPrice = 0.1;
        double bwHighPrice = 0.075;

        if (isColor) {
            return (page < colorPageThreshould)
                ? page * colorHighPrice
                : colorPageThreshould * colorHighPrice + (page - colorPageThreshould) * colorLowPrice;
        } else {
            return (page < bwPageThreshould)
                    ? page * bwHighPrice
                    : bwPageThreshould * bwHighPrice + (page - bwPageThreshould) * bwLowPrice;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        DocumentationTask that = (DocumentationTask) o;
        return page == that.page && Objects.equals(documentType, that.documentType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), page, documentType);
    }

    @Override
    public String toString() {
        return "CodingTask{" +
                "page=" + page +
                ", documentType='" + documentType + '\'' +
                '}' + super.toString();
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
}
