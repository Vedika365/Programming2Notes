package org.example;

import java.util.Comparator;
import java.util.Objects;

public abstract class Task {
    protected int id;
    protected String name;
    protected int expectedAmountOfDay;

    public Task() {
        this.id = 0;
        this.name = "";
        this.expectedAmountOfDay = 0;
    }

    public Task(int id, String name, int expectedAmountOfDay) {
        this.id = id;
        this.name = name;
        this.expectedAmountOfDay = expectedAmountOfDay;
    }

    public abstract void process();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return id == task.id && expectedAmountOfDay == task.expectedAmountOfDay && Objects.equals(name, task.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, expectedAmountOfDay);
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", expectedAmountOfDay=" + expectedAmountOfDay +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExpectedAmountOfDay() {
        return expectedAmountOfDay;
    }

    public void setExpectedAmountOfDay(int expectedAmountOfDay) {
        this.expectedAmountOfDay = expectedAmountOfDay;
    }

    public static class TaskComparator implements Comparator<Task> {
        private String type;

        public TaskComparator(String type) {
            this.type = type;
        }

        @Override
        public int compare(Task o1, Task o2) {
            return switch (type.toLowerCase()) {
                case "name" -> o1.name.compareTo(o2.name);
                case "expected" -> o1.expectedAmountOfDay - o2.expectedAmountOfDay;
                default -> o1.id - o2.id;
            };
        }
    }

}
