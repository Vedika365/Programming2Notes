package org.example;

import java.util.Objects;

public class CodingTask extends Task {
    private int length;
    private String language;

    public CodingTask() {
        super();
        this.length = 0;
        this.language = "";
    }

    public CodingTask(int id, String name, int expectedAmountOfDay, int length, String language) {
        super(id, name, expectedAmountOfDay);
        this.length = length;
        this.language = language;
    }

    /**
     * prints Coding task version of processing message
     */
    @Override
    public void process() {
        System.out.println("Processing...");
        System.out.printf("%d lines of %s code", length, language);
    }

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        CodingTask that = (CodingTask) o;
        return length == that.length && Objects.equals(language, that.language);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), length, language);
    }

    @Override
    public String toString() {
        return "CodingTask{" +
                "length=" + length +
                ", language='" + language + '\'' +
                '}' + super.toString();
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
