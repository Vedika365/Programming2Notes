package org.example;

import java.util.ArrayList;
import java.util.List;

/*
1. F
2. F
3. F
4. T
5. T

1. B
2. D
3. C
4. B
5. C

1. extends
2. default
3. Comparator
4. ArrayList<Long> nums = new ArrayList<>();
5. FileWriter
 */
public class Main {

    public static void main(String[] args) {

    }

    public static ArrayList<Integer> merge(ArrayList<Integer> nums1, ArrayList<Integer> nums2) {
        if (nums1 == null && nums2 == null) {
            return null;
        }

        ArrayList<Integer> nums3 = new ArrayList<>();

        if (nums1 != null) {
            for (Integer num : nums1) {
                if (num != null && num >= 0) {
                    nums3.add(num);
                }
            }
        }

        if (nums2 != null) {
            for (Integer num : nums2) {
                if (num != null && num >= 0) {
                    nums3.add(num);
                }
            }
        }

        return nums3;
    }

    public static double[] insert(double[] nums, double value) {
        if (nums == null) {
            return new double[]{value};
        }

        double[] nums2 = new double[nums.length + 1]; //{9,0,0,0}

        nums2[0] = value;

        for (int i = 0; i < nums.length; i++) {
            nums2[i + 1] = nums[i];
        }

        return  nums2;
    }

    public static void insert(ArrayList<Double> nums, double value) {
        nums.add(0, value);
    }

    /**
     * modifies the array by multiplying each element by the factor.
     * @param nums the original array
     * @param factor the factor to multiply with
     */
    public static void multiply(double[] nums, double factor) {
        if (nums == null) {
            return;
        }

        for (int i = 0; i < nums.length; i++) {
            nums[i] *= factor;
        }
    }

    /**
     * counts the negative numbers within an arraylist
     * @param nums the input arraylist
     * @return the number of negative elements
     */
    public static int countNegative(ArrayList<Integer> nums) {
        if (nums == null) {
            return 0;
        }

        int count = 0;

        for (Integer num : nums) {
            if (num < 0) {
                count++;
            }
        }

        return count;
    }



}