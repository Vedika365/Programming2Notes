package org.example;

public interface Printable {
    double calcPrice(boolean isColor);
}
