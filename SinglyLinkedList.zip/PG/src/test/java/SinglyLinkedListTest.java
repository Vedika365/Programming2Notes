import org.example.SinglyLinkedList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SinglyLinkedListTest {

    @Test
    public void testAdd_emptyList() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();

        nums.add(1);        // {1}

        Assertions.assertTrue(nums.size() == 1 && nums.get(0) == 1);
    }

    @Test
    public void testAdd_normalList() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);

        Assertions.assertTrue(nums.size() == 3
                && nums.get(0) == 1
                && nums.get(1) == 2
                && nums.get(2) == 3);
    }

    @Test
    public void testAddWithIdx_emptyList() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(0, 1);

        Assertions.assertTrue(nums.size() == 1
                && nums.get(0) == 1);
    }

    @Test
    public void testAddWithIdx_atBeginning() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(0, 1);
        nums.add(0, 2);

        Assertions.assertTrue(nums.size() == 2
                && nums.get(0) == 2
                && nums.get(1) == 1);
    }

    @Test
    public void testAddWithIdx_atEnd() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(0, 1);
        nums.add(1, 2);
        nums.add(2, 3);

        Assertions.assertTrue(nums.size() == 3
                && nums.get(0) == 1
                && nums.get(1) == 2
                && nums.get(2) == 3);
    }

    @Test
    public void testAddWithIdx_atRandomPlace() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(0, 1);
        nums.add(1, 2);
        nums.add(2, 3);
        nums.add(1, 4);     // {1 4 2 3}

        Assertions.assertTrue(nums.size() == 4
                && nums.get(0) == 1
                && nums.get(1) == 4
                && nums.get(2) == 2
                && nums.get(3) == 3);
    }

    @Test
    public void testRemoveWithIdx_ListWithOneNode() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(1);
        nums.remove(0);

        Assertions.assertTrue(nums.size() == 0
                && nums.getHead() == null);
    }

    @Test
    public void testRemoveWithIdx_RemoveFirstElement() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.remove(0);

        Assertions.assertTrue(nums.size() == 2
                && nums.get(0) == 2
                && nums.get(1) == 3);
    }

    @Test
    public void testRemoveWithIdx_RemoveLastElement() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.remove(2);

        Assertions.assertTrue(nums.size() == 2
                && nums.get(0) == 1
                && nums.get(1) == 2);
    }

    @Test
    public void testRemoveWithIdx_RemoveRandomElement() {
        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        nums.add(1);
        nums.add(2);
        nums.add(3);
        nums.remove(1);

        Assertions.assertTrue(nums.size() == 2
                && nums.get(0) == 1
                && nums.get(1) == 3);
    }
}
