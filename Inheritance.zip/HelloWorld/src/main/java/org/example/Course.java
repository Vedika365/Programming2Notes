package org.example;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@EqualsAndHashCode
@ToString
@Getter
@Setter
public class Course {
    private String id;
    private String name;
    private Teacher teacher;

    private static int nextId = 1;

    public Course(String name) {
        this(name, null);
    }

    public Course(String name, Teacher teacher) {
        this.id = String.format("%05d", nextId++);
        this.name = name;
        this.teacher = teacher;
    }
}
