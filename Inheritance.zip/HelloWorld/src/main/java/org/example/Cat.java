package org.example;

import java.util.Objects;

public class Cat extends Animal {
    private String breed;

    public Cat() {
        super();
        this.breed = "NaN";
    }

    public Cat(int id, String name, int age, String gender, String breed) {
        super(id, name, age, gender);
        this.breed = breed;
    }

    @Override
    public void makeSound() {
        System.out.println("mew mew");
    }

    public void makeSound(int level) {
        String message =
                switch (level) {
                    case 1 -> "MEW";
                    case 2 -> "Mew";
                    case 3 -> "mew";
                    default -> "...";
        };
        System.out.println(message);
    }

    @Override
    public String toString() {
        return "Cat{" +
                "breed='" + breed + '\'' +
                super.toString() + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Cat cat = (Cat) o;
        return Objects.equals(breed, cat.breed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), breed);
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
}
