package org.example;

public class Dog extends Animal {
    private int dangerousLevel;
}
