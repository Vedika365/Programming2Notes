package org.example;


import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Animal a = new Cat();

        if (a instanceof Cat cat) {
            cat.makeSound(3);
        }
    }
}
