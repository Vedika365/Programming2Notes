package org.example;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class Teacher {
    private String id;
    private String name;

    private static int nextId = 1;

    public Teacher(String name) {
        this.id = String.format("%05d", nextId++);
        this.name = name;
    }
}
