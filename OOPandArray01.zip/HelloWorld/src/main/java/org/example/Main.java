package org.example;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // 1 2 3 4 5
        // spaces around operators expect ++ -- !
        int[] nums = {1, 2, 3, 4, 5};           // length = 5
        int[] nums2 = new int[100];             // length = 100
        int[] nums3 = new int[100];             // length = 100
        int[] nums4 = new int[100];
        Arrays.fill(nums4, 5);
        System.out.println(Arrays.toString(nums4));
        System.out.println(Arrays.equals(nums2, nums3));

        // Arrays class
        // 1. Arrays.toString(array)
        // 2. Arrays.equals(array1, array2)
        // 3. Arrays.fill(array, value)
        // 4. Arrays.copyOf(array, len)
        // 5. Arrays.copyOfRange(array, startIdx, endIdx)

        // fetch one element
        // str.charAt(0)
        System.out.println(nums[0]);

        // fetch a range of element         // hello ell
        // str.substring(1, 4)
        int[] nums5 = Arrays.copyOfRange(nums, 1, 3);
        System.out.println(Arrays.toString(nums5));

        // enhanced-for loop
        // nums = {1, 2, 3, 4, 5}
        sum(nums);



    }

    /**
     * sums all elements of an array
     * @param nums an int array to be summed up
     * @return the sum of all elements of the input array
     */
    public static int sum(int[] nums) {
        int sum = 0;

        // regualr for loop
        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
        }

        // enhanced for loop
        for (int num : nums) {     // : can be understood as "in"
            sum += num;
        }
        return sum;
    }

}