package org.example;


import org.example.park.*;
import org.example.petstore.Animal;
import org.example.petstore.Cat;
import org.example.petstore.Dog;
import org.example.petstore.PetStore;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        ArrayList<Cat> cats = new ArrayList<>();

        cats.add(new Cat(1, "Snow", 3, "female", "orange"));
        cats.add(new Cat(2, "Angel", 1, "male", "orange"));
        cats.add(new Cat(3, "Lucky", 5, "male", "unknown"));
        cats.add(new Cat(4, "Lucy", 2, "female", "orange"));
        cats.add(new Cat(4, "AAA", 1, "female", "orange"));

        Collections.sort(cats, new Cat.CatComparator("xxx"));

        System.out.println(cats);

    }
}
