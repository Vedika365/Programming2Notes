package org.example.petstore;

public class Dog extends Animal {
    private int dangerousLevel;


    public void makeSound() {
        System.out.println("Woof woof");
    }

    public void followOrder() {
        System.out.println("Yes master");
    }

    @Override
    public String toString() {
        return "Dog{" +
                "dangerousLevel=" + dangerousLevel +
                '}' + super.toString();
    }
}
