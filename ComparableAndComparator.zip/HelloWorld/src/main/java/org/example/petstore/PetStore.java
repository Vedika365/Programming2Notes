package org.example.petstore;

import java.util.ArrayList;

public class PetStore {
    private ArrayList<Animal> animals;

    public PetStore() {
        this.animals = new ArrayList<>();
    }

    /**
     * adds a new pet into the animal arraylist
     * @param animal the new animal
     */
    public void addPet(Animal animal) {
        animals.add(animal);
        System.out.println(animal.getName() + "is added successfully");
    }

    public ArrayList<Animal> getAnimals() {
        return animals;
    }
}
