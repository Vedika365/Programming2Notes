package org.example.petstore;

import java.util.Comparator;
import java.util.Objects;

public class Cat extends Animal {
    private String breed;

    public Cat() {
        super();
        this.breed = "NaN";
    }

    public Cat(int id, String name, int age, String gender, String breed) {
        super(id, name, age, gender);
        this.breed = breed;
    }

    public void makeSound() {
        System.out.println("meow meow");
    }

    public void makeSound(int level) {
        String message =
                switch (level) {
                    case 1 -> "MEOW";
                    case 2 -> "Meow";
                    case 3 -> "meow";
                    default -> "...";
        };
        System.out.println(message);
    }

    @Override
    public String toString() {
        return "Cat{" +
                "breed='" + breed + '\'' +
                super.toString() + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Cat cat = (Cat) o;
        return Objects.equals(breed, cat.breed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), breed);
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public static class CatComparator implements Comparator<Cat> {
        private String type;

        public CatComparator(String type) {
            this.type = type;
        }

        @Override
        public int compare(Cat o1, Cat o2) {
            return switch (type) {
                case "age" -> o1.age - o2.age;
                case "name" -> o1.name.compareTo(o2.name);
                case "gender" -> o1.gender.compareTo(o2.gender);
                default -> o1.id - o2.id;
            };
        }
    }
}
