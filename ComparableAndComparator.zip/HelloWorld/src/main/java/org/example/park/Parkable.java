package org.example.park;

public interface Parkable {
    static final double FEE = 20;

    default boolean register() {
        System.out.println("Register successfully");
        return true;
    }

    default boolean pay(double amount) {
        System.out.println("Thank you for the payment");
        return true;
    }

    default boolean cancel() {
        System.out.println("Sorry to see you go");
        return true;
    }
}
