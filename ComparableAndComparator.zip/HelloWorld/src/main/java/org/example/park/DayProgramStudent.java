package org.example.park;

public class DayProgramStudent extends Student implements Parkable {
    @Override
    public boolean pay(double amount) {
        return false;
    }

    @Override
    public boolean cancel() {
        return false;
    }
}
