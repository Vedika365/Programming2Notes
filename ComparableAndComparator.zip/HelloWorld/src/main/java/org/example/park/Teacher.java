package org.example.park;

public abstract class Teacher extends User {
}
