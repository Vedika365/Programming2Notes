package org.example.park;

public class CountedStudent extends Student {
}
