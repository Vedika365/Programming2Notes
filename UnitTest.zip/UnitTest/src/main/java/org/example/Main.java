package org.example;

public class Main {
    public static void main(String[] args) {
        System.out.println(fibonacci(10));
    }

    public static Long fibonacci(int num) {
        if (num < 0) {
            return null;
        }
        if (num == 1) {
            return (long) 1;
        }
        long result = 0;

        long f0 = 0;
        long f1 = 1;
        for (int i = 2; i <= num; i++) {
            result = f0 + f1;
            f0 = f1;
            f1 = result;
        }

        return result;
    }
}