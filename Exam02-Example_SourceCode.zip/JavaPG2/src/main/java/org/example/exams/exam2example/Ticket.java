package org.example.exams.exam2example;

import java.time.LocalDateTime;
import java.util.Objects;

public class Ticket {
    private int id;
    private String title;
    private String detail;
    private String creator;
    private LocalDateTime creationTime;
    private Status status;
    private String technician;  // only contains the name of the technician

    private static int nextId = 1;

    public Ticket(String title, String detail, String creator) {
        this.id = nextId++;
        this.title = title;
        this.detail = detail;
        this.creator = creator;
        this.creationTime = LocalDateTime.now();
        this.status = Status.OPEN;
        this.technician = null;
    }

    public Ticket(int id, String title, String detail, String creator, LocalDateTime creationTime, Status status, String technician) {
        this.id = id;
        this.title = title;
        this.detail = detail;
        this.creator = creator;
        this.creationTime = creationTime;
        this.status = status;
        this.technician = technician;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Ticket ticket = (Ticket) o;
        return id == ticket.id && Objects.equals(title, ticket.title) && Objects.equals(detail, ticket.detail) && Objects.equals(creator, ticket.creator) && Objects.equals(creationTime, ticket.creationTime) && status == ticket.status && Objects.equals(technician, ticket.technician);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, detail, creator, creationTime, status, technician);
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", detail='" + detail + '\'' +
                ", creator=" + creator +
                ", creationTime=" + creationTime +
                ", status=" + status +
                ", technician=" + technician +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public LocalDateTime getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(LocalDateTime creationTime) {
        this.creationTime = creationTime;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getTechnician() {
        return technician;
    }

    public void setTechnician(String technician) {
        this.technician = technician;
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        Ticket.nextId = nextId;
    }

    public enum Status {
        OPEN, PROCESSING, CLOSED
    }
}
