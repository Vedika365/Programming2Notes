package org.example.exams.exam2example;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Technician extends User {
    private List<Ticket> onGoingTickets;
    public Technician(String name, User.Gender gender) {
        super(name, gender);
        this.onGoingTickets = new ArrayList<>();
    }

    /**
     * fetches a new ticket from the ticket system opened tickets,
     * update its status, technician and then add it to the technician's onGoingtickets list
     */
    public void fetchNewTicket() {
        Ticket ticket = TicketSystem.openedTickets.poll();
        ticket.setTechnician(this.getName());
        ticket.setStatus(Ticket.Status.PROCESSING);
        onGoingTickets.add(ticket);

        TicketSystem.export();
    }

    /**
     * close a ticket, change its status, remove it from the onGoingTickets of a technician
     * and add it to the completedTickets list of the ticket system
     * @param ticket the ticket to close
     */
    public void closeTicket(Ticket ticket) {
        ticket.setStatus(Ticket.Status.CLOSED);
        onGoingTickets.remove(ticket);
        TicketSystem.completedTickets.add(ticket);

        TicketSystem.export();
    }

    /**
     * reassign a ticket to another technician
     * @param ticket the ticket to be reassigned
     * @param technician the new technician
     */
    public void reassignTo(Ticket ticket, Technician technician) {
        ticket.setTechnician(technician.getName());
        onGoingTickets.remove(ticket);
        technician.onGoingTickets.add(ticket);
    }

    /**
     * search for tickets that contains the keyword in their title from the completedTickets list
     * @param keyword the keyword to search for
     * @return a list of completed tickets that contains keyword in their titles
     */
    public List<Ticket> searchCompletedTicket(String keyword) {
        return TicketSystem.completedTickets.stream()
                .filter(t -> t.getTitle().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Technician that = (Technician) o;
        return Objects.equals(onGoingTickets, that.onGoingTickets);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), onGoingTickets);
    }

    @Override
    public String toString() {
        return "Technician{" +
                "onGoingTickets=" + onGoingTickets +
                '}';
    }

    public List<Ticket> getOnGoingTickets() {
        return onGoingTickets;
    }

    public void setOnGoingTickets(List<Ticket> onGoingTickets) {
        this.onGoingTickets = onGoingTickets;
    }
}
