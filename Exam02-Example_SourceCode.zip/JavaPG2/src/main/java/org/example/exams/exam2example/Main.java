package org.example.exams.exam2example;

import java.util.*;

public class Main  {
    public static void main(String[] args) {
        String str = "hello";
    }

    /**
     * reverses a string
     * @param str the original string
     * @return the reversed string
     */
    public static String reverse(String str) {
        if (str == null || str.length() <= 1) {
            return str;
        }

        return reverse(str.substring(1)) + str.charAt(0);
    }

    /**
     * removes all strings whose length bigger than the average length,
     * for the remaining strings, convert it to lowercase and repeat it twice, and return the new list
     * @param strs the original list of string
     * @return the processed list of string
     */
    public static List<String> process(List<String> strs) {
        double avg = 0;

        for (String str : strs) {
            avg += str.length();
        }
        avg /= strs.size();

        double finalAvg = avg;
        return strs.stream()
                .filter(str -> str.length() < finalAvg)
                .map(String::toLowerCase)
                .map(str -> str + str)
                .toList();
    }

}