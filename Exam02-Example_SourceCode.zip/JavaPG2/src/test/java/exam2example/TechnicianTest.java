package exam2example;

import org.example.exams.exam2example.Technician;
import org.example.exams.exam2example.Ticket;
import org.example.exams.exam2example.TicketSystem;
import org.example.exams.exam2example.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

public class TechnicianTest {
    @Test
    public void testSearchCompletedTicket() {
        Ticket t1 = new Ticket("java", "", null);
        Ticket t2 = new Ticket("Java aaa", "", null);
        Ticket t3 = new Ticket("JAVA aaa", "", null);
        Ticket t4 = new Ticket("Ja  va aaa", "", null);
        Ticket t5 = new Ticket("aaa java", "", null);
        Ticket t6 = new Ticket("python", "", null);
        TicketSystem.completedTickets = List.of(t1, t2, t3, t4, t5, t6);

        Technician technician = new Technician("", User.Gender.MALE);
        List<Ticket> expected = List.of(t1, t2, t3, t5);
        List<Ticket> result = technician.searchCompletedTicket("java");

        Assertions.assertEquals(expected, result);
    }
}
