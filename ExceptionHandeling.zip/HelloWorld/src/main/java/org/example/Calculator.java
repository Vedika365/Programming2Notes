package org.example;

public class Calculator {
    private int num1;
    private int num2;
    private char oper;

    public Calculator(int num1, int num2, char oper) {
        this.num1 = num1;
        this.num2 = num2;
        this.oper = oper;
    }

    public Integer calc() {
        try {
            if (num1 == 3 || num2 == 3) {
                throw new IllegalNumberException("hey, number cannot be 3");
            }
            return switch (oper) {
                case '*' -> multiply();
                case '/' -> divide();
                case '%' -> mod();
                default -> null;
            };
        } catch (ArithmeticException e) {
            return null;
        }
    }

    private Integer mod() throws ArithmeticException {
        return num1 % num2;
    }

    private Integer divide() throws ArithmeticException {
        return num1 / num2;
    }

    private int multiply() {
        return num1 * num2;
    }

    
}
