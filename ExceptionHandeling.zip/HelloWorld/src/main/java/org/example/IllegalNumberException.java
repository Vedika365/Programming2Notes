package org.example;

public class IllegalNumberException extends RuntimeException {
    public IllegalNumberException() {
    }

    public IllegalNumberException(String message) {
        super(message);
    }
}
