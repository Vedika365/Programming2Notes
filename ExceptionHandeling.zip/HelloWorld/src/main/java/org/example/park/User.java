package org.example.park;

public abstract class User  {

    public void greet() {
        System.out.println("hello");
    }
}
