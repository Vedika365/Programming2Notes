package org.example.park;

public abstract class Student extends User {
}
