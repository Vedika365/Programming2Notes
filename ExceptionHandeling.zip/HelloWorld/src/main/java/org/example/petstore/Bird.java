package org.example.petstore;

public class Bird extends Animal {
    public void makeSound() {
        System.out.println("Qiu Qiu");
    }
}
