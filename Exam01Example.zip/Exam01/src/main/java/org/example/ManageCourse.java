package org.example;

public interface ManageCourse {
    boolean register(Course course);
    boolean drop(Course course);
}
