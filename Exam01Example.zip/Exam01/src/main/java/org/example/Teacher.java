package org.example;

import java.util.Objects;

public class Teacher extends User implements Payable {
    private int workExperience;

    private static double[] salaries = {
            80208, 82972, 85737, 88502, 91266, 95507, 99748, 103989, 108230, 112471 };

    public Teacher() {
        super();
        this.workExperience = 0;
    }

    public Teacher(int id, String name, int age, String gender, int workExperience) {
        super(id, name, age, gender);
        this.workExperience = workExperience;
    }

    /**
     * calculate the salary of a teacher based on their work experience
     * @return the salary of a teacher
     */
    @Override
    public double calcSalary() {
        int idx = Math.min(workExperience, 9);

        return salaries[idx];
    }

    /**
     * Teacher version of report
     * @param title the title of the report
     * @param context the context of the report
     */
    @Override
    public void report(String title, String context) {
        String message = String.format("Teacher, ID: %d, Name: %s\n", id, name);
        message += String.format("Title: %s\n", title);
        message += String.format("Context: %s\n", context);

        System.out.println(message);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Teacher teacher = (Teacher) o;
        return workExperience == teacher.workExperience;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), workExperience);
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "workExperience=" + workExperience +
                '}' + super.toString();
    }

    public int getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(int workExperience) {
        this.workExperience = workExperience;
    }

    public static double[] getSalaries() {
        return salaries;
    }

    public static void setSalaries(double[] salaries) {
        Teacher.salaries = salaries;
    }
}
