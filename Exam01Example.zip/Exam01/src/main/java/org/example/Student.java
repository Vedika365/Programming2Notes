package org.example;

import java.util.ArrayList;
import java.util.Objects;

public class Student extends User implements ManageCourse {
    private ArrayList<Course> courses;

    public Student() {
        super();
        this.courses = new ArrayList<>();
    }

    public Student(int id, String name, int age, String gender, ArrayList<Course> courses) {
        super(id, name, age, gender);
        this.courses = courses;
    }

    /**
     * Student version of report
     * @param title the title of the report
     * @param context the context of the report
     */
    @Override
    public void report(String title, String context) {
        String message = String.format("Student, ID: %d, Name: %s\n", id, name);
        message += String.format("Title: %s\n", title);
        message += String.format("Context: %s\n", context);

        System.out.println(message);
    }

    /**
     * registers a course if it is not registered yet
     * @param course the course to register
     * @return if the course is successfully registered
     */
    @Override
    public boolean register(Course course) {
        if (courses.contains(course)) {
            return false;
        }
        courses.add(course);
        return true;
    }

    /**
     * drops a course if it is registered
     * @param course the course to drop
     * @return if the course is successfully dropped
     */
    @Override
    public boolean drop(Course course) {
        if (!courses.contains(course)) {
            return false;
        }
        courses.remove(course);
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Student student = (Student) o;
        return Objects.equals(courses, student.courses);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), courses);
    }

    @Override
    public String toString() {
        return "Student{" +
                "courses=" + courses +
                '}' + super.toString();
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }
}
