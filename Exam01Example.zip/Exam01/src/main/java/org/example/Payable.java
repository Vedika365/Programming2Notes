package org.example;

public interface Payable {
    double calcSalary();
}
