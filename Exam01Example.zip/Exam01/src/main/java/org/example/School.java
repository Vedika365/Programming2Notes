package org.example;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class School {
    private ArrayList<User> users;

    public School() {
        this.users = new ArrayList<>();
    }

    public School(ArrayList<User> users) {
        this.users = users;
    }

    /**
     * exports users data into a csv file
     * @param fileName the name of file
     */
    public void export(String fileName) {
        File file = new File("src/main/resources/" + fileName);
        try (FileWriter fileWriter = new FileWriter(file)) {
            for (User user : users) {
                fileWriter.write(user.getId() + ",");
                fileWriter.write(user.getName() + ",");
                fileWriter.write(user.getAge() + ",");
                fileWriter.write(user.getGender() + ",");

                if (user instanceof Student student) {
                    ArrayList<Course> courses = student.getCourses();
                    for (int i = 0; i < courses.size(); i++) {
                        if (i == courses.size() - 1) {
                            fileWriter.write(courses.get(i).getName() + "\n");
                        } else {
                            fileWriter.write(courses.get(i).getName() + ",");
                        }
                    }
                } else if (user instanceof Teacher teacher) {
                    fileWriter.write(teacher.getWorkExperience() + "\n");
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
