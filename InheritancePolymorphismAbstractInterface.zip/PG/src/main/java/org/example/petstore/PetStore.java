package org.example.petstore;

import java.util.ArrayList;

public class PetStore {
    private ArrayList<Animal> animals;

    public PetStore() {
        this.animals = new ArrayList<>();
    }

    public void addAnimal(Animal animal) {
        animals.add(animal);
    }

    public void makeSound() {
        for (Animal animal : animals) {
            animal.makeSound();
        }
    }

    public void obey() {
        for (Animal animal : animals) {
            if (animal instanceof Dog dog) {
                dog.obey();
            }
        }
    }
}
