package org.example.petstore;

public class Bird extends Animal {
    public Bird(int age, String name) {
        super(age, name);
    }
}
