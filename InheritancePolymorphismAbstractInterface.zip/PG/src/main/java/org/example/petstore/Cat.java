package org.example.petstore;

import java.util.Objects;

public class Cat extends Animal {
    private String breed;

    public Cat() {
        super();
        this.breed = "Unknown";
    }

    public Cat(int age, String name, String breed) {
        super(age, name);
        this.breed = breed;
    }

    @Override
    public void makeSound() {
        System.out.println("Meow Meow");
    }

    public void makeSound(int level) {
        String message = switch (level) {
            case 3 -> "MEOW";
            case 2 -> "Meow";
            case 1 -> "meow";
            default -> "....";
        };

        System.out.println(message);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Cat cat = (Cat) o;
        return Objects.equals(breed, cat.breed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), breed);
    }

    @Override
    public String toString() {
        return "Cat{" +
                super.toString() + ", " +
                "breed='" + breed + '\'' +
                '}';
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
}
