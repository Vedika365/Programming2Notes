package org.example.petstore;

import java.util.Objects;

public class Dog extends Animal {
    private String breed;

    public Dog() {
        super();
        this.breed = "Unknown";
    }

    public Dog(int age, String name, String breed) {
        super(age, name);
        this.breed = breed;
    }

    @Override
    public void makeSound() {
        System.out.println("Woof woof");
    }

    public void makeSound(int level) {
        String message = switch (level) {
            case 3 -> "WOOF";
            case 2 -> "Woof";
            case 1 -> "woof";
            default -> "....";
        };

        System.out.println(message);
    }

    public void obey() {
        System.out.println("Yes master");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Dog cat = (Dog) o;
        return Objects.equals(breed, cat.breed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), breed);
    }

    @Override
    public String toString() {
        return "Dog{" +
                super.toString() + ", " +
                "breed='" + breed + '\'' +
                '}';
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
}
