package org.example;

import org.example.petstore.Cat;
import org.example.petstore.Dog;
import org.example.petstore.PetStore;

public class Main {
    public static void main(String[] args) {
        // upper casting
        PetStore p = new PetStore();
        p.addAnimal(new Cat());     // upper casting
        p.addAnimal(new Cat());     // upper casting
        p.addAnimal(new Dog());     // upper casting
        p.addAnimal(new Dog());     // upper casting


        p.obey();
    }
}