package org.example.park;

public class ContedStudent extends Student {
}
