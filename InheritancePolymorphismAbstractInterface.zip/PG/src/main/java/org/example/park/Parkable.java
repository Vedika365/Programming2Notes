package org.example.park;

public interface Parkable {
    default boolean register() {
        System.out.println("Register successfully");
        return true;
    }

    boolean pay();
    boolean cancel();
}
