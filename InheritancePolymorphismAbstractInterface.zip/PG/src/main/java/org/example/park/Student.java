package org.example.park;

public class Student extends User {
}
