package org.example.park;

public class ContractedTeacher extends Staff {
}
