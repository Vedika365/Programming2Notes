package org.example.park;

public class PermanentTeacher extends Staff implements Parkable {
}
