package org.example.park;

public class DayprogramStudent extends Student implements Parkable {
}
