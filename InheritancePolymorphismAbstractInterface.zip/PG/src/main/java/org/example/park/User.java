package org.example.park;

public class User {
}
