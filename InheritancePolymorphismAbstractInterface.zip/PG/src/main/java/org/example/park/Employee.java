package org.example.park;

public class Employee extends User implements Parkable {

}
