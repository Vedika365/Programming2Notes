package org.example.park;

public class Staff extends User {
}
